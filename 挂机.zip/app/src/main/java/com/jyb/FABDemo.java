package com.jyb;

import android.os.Bundle;
import android.support.v7.app.*;
import android.support.annotation.*;
import android.widget.*;



public class FABDemo extends AppCompatActivity {
private ListView mList;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fab);
      mList = (ListView) findViewById(R.id.activityfabListView1);


    
		String[] strs = {
			"王荣旺",
			"陈科帆",
			"朱安安",
			"景沈毅",
			"李士克",
			"薛义",



		};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, strs);
		mList.setAdapter(adapter);
		;}}

	
