package com.jyb;

import android.os.*;
import android.support.annotation.*;
import android.support.v7.app.*;

public class SearchBarDemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        }
}
