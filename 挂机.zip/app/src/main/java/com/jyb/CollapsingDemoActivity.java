package com.jyb;

import android.os.*;
import android.support.annotation.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;



public class CollapsingDemoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_collapsing);
		Toolbar tbAuthor = (Toolbar) findViewById(R.id.tool);
	tbAuthor.setTitle("MyApp");  // 主标题
	setSupportActionBar(tbAuthor);
	getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		
		tbAuthor.setNavigationOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					onBackPressed();
				}
			});
	
  
	}
	}
