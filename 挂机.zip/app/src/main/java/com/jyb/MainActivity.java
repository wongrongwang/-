package com.jyb;

import android.os.*;
import android.support.design.*;
import android.support.v4.widget.*;
import android.support.v7.app.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;

import android.support.design.R;
import android.support.v7.widget.Toolbar;
import android.support.design.widget.*;
import android.content.*;
public class MainActivity extends AppCompatActivity 
{
  
	private NavigationView mNavigationView;
	
 private ListView mList;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar); //绑定工具栏ID
		toolbar.setTitle("MyApp");  // 主标题 
		toolbar.setSubtitle("Wrw");//副标题
	setSupportActionBar(toolbar);//替换系统
		DrawerLayout drawer=(DrawerLayout) findViewById(R.id.chehua);//绑定侧滑ID
		ActionBarDrawerToggle toggle=new ActionBarDrawerToggle(this,drawer,toolbar,R.string.app_name,R.string.app_name){};
   	 	//标题栏左侧显示一个菜单按钮
		mNavigationView = (NavigationView) findViewById(R.id.navigation);
		
        //设置侧滑菜单选择监听事件
		toggle.syncState();
   	 	//绑定侧滑监听器
		setupDrawerContent(mNavigationView);
	drawer.setDrawerListener(toggle);
      mList = (ListView) findViewById(R.id.list);

		
      

       String[] strs = {
        "王荣旺",
       "陈科帆",
       "朱安安",
        "景沈毅",
	"李士克",
	"薛义",

	

    };
ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, strs);
    mList.setAdapter(adapter);
		mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(MainActivity.this, "点击了" + i, Toast.LENGTH_SHORT).show();
            }
        });}
	public boolean onCreateOptionsMenu(Menu menu)
	{	getMenuInflater().inflate(R.menu.toolbar,menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId()){

			case R.id.exit:
				finish();
				break;
			default:
		}
		return super.onOptionsItemSelected(item);
		//标题栏右侧
	}
	private void setupDrawerContent(NavigationView navigationView)
    {
        navigationView.setNavigationItemSelectedListener(

			new NavigationView.OnNavigationItemSelectedListener()
			{

				private String i;

				@Override
				public boolean onNavigationItemSelected(MenuItem menuItem)
				{


							
					switch (menuItem.getItemId()) {
						case R.id.nav_manage:
							onBackPressed();
							break;
						case R.id.nav_suggestion:
							Toast.makeText(MainActivity.this, "点击了" + i, Toast.LENGTH_SHORT).show();
							startActivity(new Intent(MainActivity.this, FABDemo.class));
							break;
						case R.id.nav_me:
							Toast.makeText(MainActivity.this, "点击了" + i, Toast.LENGTH_SHORT).show();
							startActivity(new Intent(MainActivity.this,CollapsingDemoActivity.class));
							break;
						case R.id.nav_setting:
							Toast.makeText(MainActivity.this, "点击了" + i, Toast.LENGTH_SHORT).show();
							startActivity(new Intent(MainActivity.this, SearchBarDemoActivity.class));
							break;
						case R.id.nav_about:
							Toast.makeText(MainActivity.this, "点击了" + i, Toast.LENGTH_SHORT).show();
							break;
					}
					menuItem.setChecked(true);
					//关闭抽屉
				
					return false;
				}
			
    });}}

        


	
